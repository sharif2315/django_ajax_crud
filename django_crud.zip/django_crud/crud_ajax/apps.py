from django.apps import AppConfig


class CrudAjaxConfig(AppConfig):
    name = 'crud_ajax'
